﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class Quadrilateral:Shape//四边形类
{
       //you define
}

