﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class Rhombus:Parallelogram//菱形
    {
    //you can define.
    }
