﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


class Rectangle:Parallelogram//长方形
{
    //you can define.
}

