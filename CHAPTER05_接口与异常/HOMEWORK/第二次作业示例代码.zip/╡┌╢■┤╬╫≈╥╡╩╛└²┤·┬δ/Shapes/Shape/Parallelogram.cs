﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


public class Parallelogram:Trapaezoid//平行四边形
    {
      //you define
    }

