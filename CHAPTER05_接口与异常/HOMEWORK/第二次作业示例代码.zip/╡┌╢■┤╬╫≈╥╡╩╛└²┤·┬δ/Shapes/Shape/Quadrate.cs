﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class Quadrate:Rhombus//正方形
    {
    }

